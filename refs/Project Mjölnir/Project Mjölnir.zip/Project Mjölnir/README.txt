Hi there and welcome! Thanks alot for checking out Mjölnir - We've been so excited to share this with you, that we simply could'nt wait any longer. This blaster is for the community, by the community. 

This is the finished blaster after about 8 months of work from alot of cool people, but we are hobby-nerf folk, not professionals (Try it out at your own risk).

This is a personal blaster for you and we want you to mod it. There is however a few legal things; The code is a mix of Airzone's free code. This means you are not allowed to sell it. The same goes for the design, which is mainly because we dont want to get kicked off github later on.. 😛 

But you are free to use it as you please to mod etc. You can print all the blasters you want for friends and family for the cost of filament and hugs.

if you have any questions, feel free to reach out to us via discord (https://discord.gg/Edy7qAxdAY) or facebook. 

Kind regards,

Ben, Thor and the rest of the C.R.A.P team

(Cross Rough Atlantic Projects)